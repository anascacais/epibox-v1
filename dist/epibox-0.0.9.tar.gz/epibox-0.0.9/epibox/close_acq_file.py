def close_acq_file(a_file):
	a_file.close()

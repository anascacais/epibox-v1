def close_drift_log_file(drift_log_file):
	drift_log_file.close()

def close_annot_file(annot_file):
	annot_file.close()

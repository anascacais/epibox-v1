from find import * 

def str2np(string):
	str_R = find(string,']')
	i = 5
	return str_R
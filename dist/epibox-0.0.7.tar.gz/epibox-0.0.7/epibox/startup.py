import subprocess

print('starting...')
subprocess.run(['python3', '-i', '/home/pi/Documents/Project/PreEpiSeizures/mqtt_startup.py'], shell=True)         